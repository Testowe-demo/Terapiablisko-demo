# TerapiaBlisko
Strona demonstracyjna dla projektu terapeutycznego.

## Jak uruchomić
1. Wgraj pliki do swojego repozytorium na GitHub.
2. Włącz GitHub Pages w ustawieniach repozytorium.
3. Gotowe — strona będzie dostępna online.
